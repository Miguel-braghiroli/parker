package sv.edu.catolica.dp_menu;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private TextView Mensaje;
    private EditText otroMensaje;
    private ListView lista;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Mensaje = findViewById(R.id.tvMensaje);
        otroMensaje = findViewById(R.id.etHere);
        lista = findViewById(R.id.lista);
        registerForContextMenu(Mensaje);
        registerForContextMenu(lista);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_principal, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) menuInfo;

        if (v.getId() == R.id.etHere){
            getMenuInflater().inflate(R.menu.menu_contextual1, menu);
        }else if (v.getId() == R.id.lista){
            menu.setHeaderTitle(lista.getItemAtPosition(info.position).toString());
            getMenuInflater().inflate(R.menu.menu_contextual2, menu);
        }
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.edit:
                Mensaje.setText(getString(R.string.aviso) + getText(R.string.text_op3));
                return true;
            case R.id.delete:
                Mensaje.setText(getString(R.string.aviso) + getText(R.string.text_op4));
                return true;
            case R.id.search:
                Mensaje.setText(getString(R.string.aviso) + getText(R.string.text_op2));
                return true;
            case R.id.add:
                Mensaje.setText(getString(R.string.aviso) + getText(R.string.text_op1));
                return true;
            case R.id.setting:
                Mensaje.setText(getString(R.string.aviso) + getText(R.string.text_op5));
                return true;
            default: return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item;
        switch (item.getItemId()){
            case R.id.opColor:
                otroMensaje.setTextColor(Color.GREEN);
                return true;
            case R.id.opTexto:
                otroMensaje.setText("Algo nuevo");
                return true;
            case R.id.opEnviarTextView:
                Mensaje.setText(lista.getItemAtPosition(info.position).toString());
                return true;
            case R.id.opEnviarEditText:
                otroMensaje.setText(lista.getItemAtPosition(info.position).toString());
                return true;
            default: return super.onContextItemSelected(item);
        }
    }
}