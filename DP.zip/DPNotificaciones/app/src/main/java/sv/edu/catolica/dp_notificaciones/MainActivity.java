package sv.edu.catolica.dp_notificaciones;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity {
    public final int DURACION_MENSAJE = 5000;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void MonstrarInformativo(View view) {
        AlertDialog.Builder objMensaje = new AlertDialog.Builder(this);
        objMensaje.setCancelable(false);
        objMensaje.setTitle("Ventana de Alerta");
        objMensaje.setMessage("Bienvenidos a la Practica");
        objMensaje.setPositiveButton("Ok", null);
        objMensaje.create();
        objMensaje.show();
    }

    public void PedirConfirmacion(View view) {
        AlertDialog.Builder objMensaje = new AlertDialog.Builder(this);
        objMensaje.setCancelable(false);
        objMensaje.setTitle("Ventana de Confirmacion");
        objMensaje.setMessage("¿Le parece interesante la app");
        objMensaje.setPositiveButton("Si", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Toast.makeText(MainActivity.this,
                        "Nos agrada saber que le gusta",
                        Toast.LENGTH_SHORT).show();
            }
        });
        objMensaje.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Snackbar.make(view,
                        "Vuelva a intentar :c",
                        DURACION_MENSAJE).setAction("Ok", new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        LayoutInflater diseno = getLayoutInflater();
                        View mivista = diseno.inflate(R.layout.ventana_personal,
                                findViewById(R.id.MiContenedor));

                        TextView MiTextoPersonal = mivista.findViewById(R.id.MiTextoPersonal);
                        MiTextoPersonal.setText("algo diferente");
                        Toast MiVentana = new Toast(getApplicationContext());
                        MiVentana.setView(mivista);
                        MiVentana.show();
                    }
                }).show();
            }
        });
        objMensaje.create();
        objMensaje.show();
    }

    public void HacerSeleccion(View view) {
        String opciones[]={"Pollo", "Carne", "Pescado", "Camarones"};
        AlertDialog.Builder objMensaje = new AlertDialog.Builder(this);
        objMensaje.setCancelable(false);
        objMensaje.setTitle("Opciones de Menu");
        objMensaje.setItems(opciones, new DialogInterface.OnClickListener() {
            @SuppressLint("WrongConstant")
            @Override
            public void onClick(DialogInterface dialogInterface, int indiceSeleccionado) {
                /*
                Toast aviso = new Toast(getApplicationContext());
                aviso.setText(opciones[indiceSeleccionado]+" es su comida preferida");
                aviso.setGravity(Gravity.RIGHT|Gravity.TOP,0,0);
                aviso.setDuration(DURACION_MENSAJE);
                aviso.show();
                */

                LayoutInflater diseno = getLayoutInflater();
                View mivista = diseno.inflate(R.layout.ventana_personal,
                        findViewById(R.id.MiContenedor));

                TextView MiTextoPersonal = mivista.findViewById(R.id.MiTextoPersonal);
                MiTextoPersonal.setText(opciones[indiceSeleccionado]);
                Toast MiVentana = new Toast(getApplicationContext());
                MiVentana.setView(mivista);
                MiVentana.show();
            }
        });
        objMensaje.create();
        objMensaje.show();
    }

    public void Personalizacion(View view) {
        LayoutInflater diseno = getLayoutInflater();
        View mivista = diseno.inflate(R.layout.ventana_personal,
                findViewById(R.id.MiContenedor));

        TextView MiTextoPersonal = mivista.findViewById(R.id.MiTextoPersonal);
        MiTextoPersonal.setText("Prueba de Ventana Personal");

        AlertDialog.Builder Personalizado = new AlertDialog.Builder(this);
        Personalizado.setView(mivista);
        Personalizado.setPositiveButton("Ok", null);
        Personalizado.create();
        Personalizado.show();
    }
}